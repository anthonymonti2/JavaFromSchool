package stacker;

import java.awt.*;
/**
 * Block.java  
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */
public class Block
{   
    //Shapes that make up the bigger block
    private Polygon top;
    private Polygon leftSide;
    private Polygon rightSide;
    
    //The four points needed to make the 3 different parts
    private Point origin;
    private Point topLeft;
    private Point topRight;
    private Point bottomPoint;
    
    //Height of block, never changes
    private final double height = 25;
    
    //Length and width of the block, used in finding the points
    private int length;
    private int width;
    
    //Speed in which the block moves across the screen
    private int xSpeed;
    private int ySpeed;
    
    //Where did the block start. True is the left, false is the right 
    private boolean startLeft;
    
    //True if the block is placed, false is still in play
    private boolean isPlaced = false;

    public Block(int vX, int vY, int l, int w, boolean startL)
    {  
        startLeft = startL;
        
        if(startLeft == true)
        {
            xSpeed = 2;
            ySpeed = 2;
        }
        else
        {
            xSpeed = -2;
            ySpeed = 2;
        }
                
        length = l;
        width = w;
        
        origin = new Point(vX,vY);
        topLeft = new Point(vX - width,vY + width);
        topRight = new Point(vX + length, vY + length);
        
        //Creates the top point
        top = new Polygon();
        top.addPoint((int)(origin.getX()),(int)(origin.getY()));
        top.addPoint((int)(topLeft.getX()),(int)(topLeft.getY()));
        
        //Sets the correct bottom point
        if(length > width)
        { 
            bottomPoint = new Point((int)(topLeft.getX()) + length, (int)(topLeft.getY()) + length);
            top.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY())); 
        }
        else if(width > length)
        {
            bottomPoint = new Point((int)(topRight.getX()) - width, (int)(topRight.getY()) + width);
            top.addPoint((int)(bottomPoint.getX()), (int)(bottomPoint.getY()));
        }
        else
        {
            bottomPoint = new Point((int)(origin.getX()), (int)(origin.getY()) + 100);
            top.addPoint((int)(bottomPoint.getX()), (int)(bottomPoint.getY()));
        }
        top.addPoint((int)(topRight.getX()),(int)(topRight.getY())); //Fourth
        
        //Find the points for the other sides
        rightSide = new Polygon();
        rightSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()) + (int)(height)); //Down 25 from bottom
        rightSide.addPoint((int)(topRight.getX()),(int)(topRight.getY()) + (int)(height)); //Back to bottom of top
        rightSide.addPoint((int)(bottomPoint.getX()) + width,(int)(bottomPoint.getY()) - width); //Over 50 up 50
        rightSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY())); //Up 25 to right corner
        
        
        leftSide = new Polygon();
        leftSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()) + (int)(height));
        leftSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()));   
        leftSide.addPoint((int)(bottomPoint.getX()) - length,(int)(bottomPoint.getY()) - length);
        leftSide.addPoint((int)(topLeft.getX()),(int)(topLeft.getY()) + (int)(height));
    }
    
    /**
     * Takes the 3 polygons made in the constructor and draws them on screen
     * @param g the Graphics object
     */
    public void draw(Graphics g)
    {
        g.setColor(Color.BLUE);
        g.fillPolygon(top);
        g.setColor(new Color(0,100,255));
        g.fillPolygon(leftSide);
        g.setColor(new Color(0,150,255));
        g.fillPolygon(rightSide);
    }
    
    /**
     * Moves the block to the specified x and y
     * @param dX the change in x
     * @param dY the change in y
     */
    public void move(int dX, int dY)
    {
        setOrigin((int)(origin.getX()) + dX, (int)(origin.getY()) + dY);
        setTopLeft((int)(topLeft.getX()) + dX, (int)(topLeft.getY()) + dY);
        setTopRight((int)(topRight.getX()) + dX, (int)(topRight.getY()) + dY);
        setBottom((int)(bottomPoint.getX()) + dX, (int)(bottomPoint.getY()) + dY);
        
        top.reset(); //reset the points  so the nex points are the correct changed x and y
        top.addPoint((int)(origin.getX()),(int)(origin.getY()));
        top.addPoint((int)(topLeft.getX()),(int)(topLeft.getY()));
        
        //Sets the correct bottom point
        if(length > width)
        { 
            bottomPoint = new Point((int)(topLeft.getX()) + length, (int)(topLeft.getY()) + length);
            top.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()));
        }
        else if(width > length)
        {
            bottomPoint = new Point((int)(topRight.getX()) - width, (int)(topRight.getY()) + width);
            top.addPoint((int)(bottomPoint.getX()), (int)(bottomPoint.getY()));
        }
        else
        {
            bottomPoint = new Point((int)(origin.getX()), (int)(origin.getY()) + 100);
            top.addPoint((int)(bottomPoint.getX()), (int)(bottomPoint.getY()));
        }
        top.addPoint((int)(topRight.getX()),(int)(topRight.getY()));
        
        
        rightSide.reset(); //reset the points  so the nex points are the correct changed x and y
        rightSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()) + (int)(height)); //Down 25 from bottom
        rightSide.addPoint((int)(topRight.getX()),(int)(topRight.getY()) + (int)(height)); //Back to bottom of top
        rightSide.addPoint((int)(bottomPoint.getX()) + width,(int)(bottomPoint.getY()) - width); //Over 50 up 50
        rightSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY())); //Up 25 to right corner
        
        
        leftSide.reset(); //reset the points  so the nex points are the correct changed x and y
        leftSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()) + (int)(height));
        leftSide.addPoint((int)(bottomPoint.getX()),(int)(bottomPoint.getY()));   
        leftSide.addPoint((int)(bottomPoint.getX()) - length,(int)(bottomPoint.getY()) - length);
        leftSide.addPoint((int)(topLeft.getX()),(int)(topLeft.getY()) + (int)(height));
    }
    
    /**
     * When the block is placed it sets the isPlaced variable to true and returns true
     * @return true
     */
    public boolean place()
    {
        isPlaced = true;
        return isPlaced;
    }
    
    /**
     * Resets the origin point to a x and y parameters
     * @param x the new x
     * @param y the new y
     */
    public void setOrigin(int x, int y)
    {
        origin.setLocation(x, y);
    }
    
    /**
     * Resets the top right point to a x and y parameters
     * @param x the new x
     * @param y the new y
     */
    public void setTopRight(int x, int y)
    {
        topRight.setLocation(x,y);
    }
    
    
    /**
     * Resets the top left point to a x and y parameters
     * @param x the new x
     * @param y the new y
     */
    public void setTopLeft(int x, int y)
    {
        topLeft.setLocation(x,y);
    }
    
    /**
     * Resets the bottom point to a x and y parameters
     * @param x the new x
     * @param y the new y
     */
    public void setBottom(int x, int y)
    {
        bottomPoint.setLocation(x,y);
    } 
    
    /**
     * Sets the x speed to the x parameter
     * @param x the x speed
     */
    public void setXSpeed(int x)
    {
       xSpeed = x; 
    }
    
    /**
     * Sets the y speed to the y parameter
     * @param y the y speed
     */
    public void setYSpeed(int y)
    {
       ySpeed = y; 
    }
    
    /**
     * Returns the y speed
     * @return the y speed
     */
    public int getYSpeed()
    {
        return ySpeed;
    }
    
    /**
     * Returns the x speed
     * @return the x speed
     */
    public int getXSpeed()
    {
        return xSpeed;
    }
    
    /**
     * Returns the blocks length
     * @return the blocks length
     */
    public int getLength()
    {
        return length;
    }
    
    /**
     * Returns the blocks width
     * @return the blocks width
     */
    public int getWidth()
    {
        return width;
    }
    
    /**
     * Returns the origin point as a point object
     * @return the origin point
     */
    public Point getOrigin()
    {
        return origin;
    }
    
    /**
     * Returns the top left point as a point object
     * @return the top left point
     */
    public Point getTopLeft()
    {
        return topLeft;
    }
    
    /**
     * Returns the top right point as a point object
     * @return the top right point
     */
    public Point getTopRight()
    {
        return topRight;
    }
    
    /**
     * Returns the bottom point as a point object
     * @return the bottom point
     */
    public Point getBottom()
    {
        return bottomPoint;
    }
    
    /**
     * Returns the startLeft variable
     * @return the startLeft variable
     */
    public boolean getStartLeft()
    {
        return startLeft;
    }
}
