package stacker;

import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
/**
 * Panel.java  
 *
 * @author: Anthony Montalbano
 * Assignment #: Stacker
 * 
 * Brief Program Description:
 * This class is the panel that lets the blocks be draw on
 * This class also has methods to control the speed and flow of the game
 * by using a timer to refresh every 16 ms and checks if the space bar is pressed
 *
 */
public class Panel extends JPanel
{
    Timer t;
    Block b;

    public Panel() throws Exception
    {
        setUpGame();
        //repaint();
        //run();
    }

    public void paint(Graphics g)
    {
        super.paint(g);
        b.draw(g);
    }
    
    /**
     * Instanciates some objects needed to run the game and creates a new block
     */
    public void setUpGame()
    {
        setBackground(Color.WHITE);
        b = new Block(400,100,50,50,false);
        
        t = new Timer(1000/30,new ActionListener()
        {
        public void actionPerformed(ActionEvent evt)
        {
            update();
            repaint();
        }
        });
        t.start();
    }
    
    /**
     * This method update the blocks x and y coordinates so it will be moved 
     * when the panel is refreshed
     */
    public void update()
    {
        if(b.getStartLeft() == true)
        {
            if(b.getTopLeft().getX() < 0) //Hit left side
            {
                b.setXSpeed(Math.abs(b.getXSpeed()));
                b.setYSpeed(Math.abs(b.getYSpeed()));
            }
            else if(b.getBottom().getY()> 600) //Hits bottom of screen
            {
                b.setXSpeed(b.getXSpeed() * -1);
                b.setYSpeed(b.getYSpeed() * -1);
            }
        }
        else
        {
           if(b.getTopRight().getX() > 600) //Hit right side
            {
                b.setXSpeed(b.getXSpeed() * -1);
                b.setYSpeed(Math.abs(b.getYSpeed()));
            }
            else if(b.getBottom().getY()> 600) //Hits bottom of screen
            {
                b.setXSpeed(Math.abs(b.getXSpeed()));
                b.setYSpeed(b.getYSpeed() * -1); 
            } 
        }
        b.move(b.getXSpeed(),b.getYSpeed()); 
    }  
}



