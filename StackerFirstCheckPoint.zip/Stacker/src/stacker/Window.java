package stacker;

import java.awt.*;
import javax.swing.*;
/**
 * Test.java 
 *
 * @author:
 * Assignment #:
 * 
 * Brief Program Description:
 * 
 *
 */

public class Window extends JFrame 
{
    private int gameWidth = 600; //the width of the game area
    private int gameHeight = 600;
    
    public static void main(String[] args) throws Exception
    {
        Window w = new Window();
    }
    
    public Window() throws Exception
    {
        JFrame frame = new JFrame();
        frame.setTitle("Stack");
        frame.setLayout(new BorderLayout());
        frame.setPreferredSize(new Dimension(gameWidth,gameHeight));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //frame.setBackground(Color.WHITE);
        
        Panel p = new Panel();
        
        frame.add(p);
        frame.setVisible(true);
        frame.pack();
        
        
    }
    
    
}

/**
 * Sources
 * 
 * https://www.youtube.com/watch?v=hIexVBm1cag For figuring out how to get a 
 *                                             graphics object
 * 
 */